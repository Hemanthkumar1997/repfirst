#ifndef Quad_h
#define Quad_h

#include <stdio.h>

struct Vertex
{
    float x;
    float y;
};

struct Color
{
    float r;
    float g;
    float b;
};

enum
{
    VERTEX_TOP_LEFT,
    VERTEX_BOTTOM_LEFT,
    VERTEX_BOTTOM_RIGHT,
    VERTEX_TOP_RIGHT
};

struct Quad
{
    struct Vertex vertices[4];
    struct Color color;
};

struct Quad quadCreate(struct Vertex center, struct Color color, float width, float height);

void quadSetWidth(struct Quad* q, float w);
float quadGetWidth(struct Quad* q);

void quadSetHeight(struct Quad* q, float h);
float quadGetHeight(struct Quad* q);

void quadSetCenter(struct Quad* q, struct Vertex center);
struct Vertex quadGetCenter(struct Quad* q);

void quadDraw(struct Quad* q);

#endif /* Quad_h */
